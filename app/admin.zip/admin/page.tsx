// app/admin/page.tsx  (Next.js App Router)
// or pages/admin.tsx (if using Pages Router)

// import Image from "next/image";

// export default function AdminDashboard() {
//   return (
//     <div className="flex min-h-screen font-sans bg-gray-50">
//       {/* Sidebar */}
//       <aside className="sticky top-0 flex flex-col justify-between w-64 h-screen p-4 bg-white border-r border-gray-200">
//         <div className="flex flex-col gap-8">
//           <h1 className="px-2 text-xl font-bold text-gray-800">MySANmarg Admin</h1>
//           <nav className="flex flex-col gap-2">
//             <a className="flex items-center gap-3 px-3 py-2 text-blue-700 rounded-md bg-blue-50" href="#">
//               <span className="material-symbols-outlined">dashboard</span>
//               <span className="text-sm font-medium">Dashboard</span>
//             </a>
//             <a className="flex items-center gap-3 px-3 py-2 text-gray-600 rounded-md hover:bg-gray-100" href="#">
//               <span className="material-symbols-outlined">list_alt</span>
//               <span className="text-sm font-medium">Requests</span>
//             </a>
//             <a className="flex items-center gap-3 px-3 py-2 text-gray-600 rounded-md hover:bg-gray-100" href="#">
//               <span className="material-symbols-outlined">group</span>
//               <span className="text-sm font-medium">Providers</span>
//             </a>
//             <a className="flex items-center gap-3 px-3 py-2 text-gray-600 rounded-md hover:bg-gray-100" href="#">
//               <span className="material-symbols-outlined">campaign</span>
//               <span className="text-sm font-medium">Feedback</span>
//             </a>
//           </nav>
//         </div>
//         <div className="flex flex-col gap-2">
//           <a className="flex items-center gap-3 px-3 py-2 text-gray-600 rounded-md hover:bg-gray-100" href="#">
//             <span className="material-symbols-outlined">settings</span>
//             <span className="text-sm font-medium">Settings</span>
//           </a>
//           <a className="flex items-center gap-3 px-3 py-2 text-gray-600 rounded-md hover:bg-gray-100" href="#">
//             <span className="material-symbols-outlined">logout</span>
//             <span className="text-sm font-medium">Logout</span>
//           </a>
//         </div>
//       </aside>

//       {/* Main */}
//       <main className="flex-1 p-8">
//         {/* Header */}
//         <header className="flex items-center justify-between mb-8">
//           <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" />
//           <h1 className="text-3xl font-bold text-gray-800">Dashboard</h1>
//           <div className="flex items-center gap-4">
//             <button className="relative p-2 rounded-full hover:bg-gray-100">
//               <span className="text-gray-600 material-symbols-outlined">notifications</span>
//               <span className="absolute flex w-2 h-2 top-1 right-1">
//                 <span className="absolute inline-flex w-full h-full bg-blue-400 rounded-full opacity-75 animate-ping"></span>
//                 <span className="relative inline-flex w-2 h-2 bg-blue-500 rounded-full"></span>
//               </span>
//             </button>
//             <div className="flex items-center gap-2">
//               <Image
//                 src="https://lh3.googleusercontent.com/aida-public/AB6AXuARDQ6Gqhxp-vuTkUnTWOcyARqs_bVCNbn4jQERfuqPF9MVwcaPPhMXKBcWAaJrfWvurs7IIS2np6fDp_T_Nyya0AAmp6DH0JuvXki83P83lS6oU7GBMxoMQSGyDCBjqzDBLW6HIvJ-bxC9YhFyq1Diy-N-Xh0r1EqmHM_yQZ9A0kKnil9jhPtMBIVaOE_R_AkYfoGB-aikuwBar2bfa0lHo0WGnSkUQlzC8rRlC6B0aziBJcHl7oQAp5i3PmWs42U5l0EnlCN6pG0"
//                 alt="Admin Avatar"
//                 width={40}
//                 height={40}
//                 className="object-cover rounded-full"
//               />
//               <div>
//                 <p className="text-sm font-medium text-gray-800">Admin User</p>
//                 <p className="text-xs text-gray-500">admin@mysanmarg.com</p>
//               </div>
//             </div>
//           </div>
//         </header>

//         {/* Dashboard Sections */}
//         <div className="grid grid-cols-1 gap-8 lg:grid-cols-3">
//           {/* Live Requests */}
//           <div className="col-span-1 bg-white border border-gray-200 rounded-lg shadow-sm lg:col-span-2">
//             <div className="p-4 border-b border-gray-200">
//               <h2 className="text-lg font-semibold text-gray-800">Live Requests</h2>
//             </div>
//             <div className="overflow-x-auto">
//               <table className="w-full text-sm">
//                 <thead className="text-xs text-left text-gray-500 uppercase bg-gray-50">
//                   <tr>
//                     <th className="px-6 py-3 font-medium">Request ID</th>
//                     <th className="px-6 py-3 font-medium">User</th>
//                     <th className="px-6 py-3 font-medium">Location</th>
//                     <th className="px-6 py-3 font-medium">Status</th>
//                     <th className="px-6 py-3 font-medium">Timestamp</th>
//                   </tr>
//                 </thead>
//                 <tbody className="text-gray-700 divide-y divide-gray-200">
//                   <tr>
//                     <td className="px-6 py-4 font-medium text-gray-900">REQ123</td>
//                     <td className="px-6 py-4">Rohan Sharma</td>
//                     <td className="px-6 py-4">Mumbai</td>
//                     <td className="px-6 py-4">
//                       <span className="bg-green-100 text-green-800 inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-semibold">
//                         <span className="mr-1.5 h-2 w-2 rounded-full bg-current"></span>
//                         Active
//                       </span>
//                     </td>
//                     <td className="px-6 py-4">2024-07-26 10:00</td>
//                   </tr>
//                   {/* Repeat rows same as HTML */}
//                 </tbody>
//               </table>
//             </div>
//           </div>

//           {/* Active SOS Requests Map */}
//           <div className="col-span-1 bg-white border border-gray-200 rounded-lg shadow-sm">
//             <div className="p-4 border-b border-gray-200">
//               <h2 className="text-lg font-semibold text-gray-800">Active SOS Requests Map</h2>
//             </div>
//             <div className="p-4">
//               <div
//                 className="w-full bg-center bg-cover rounded-md aspect-video"
//                 style={{
//                   backgroundImage:
//                     "url('https://lh3.googleusercontent.com/aida-public/AB6AXuCl3GuAkX2i10_AICh9_npT2idI-3U75NeRT1THLooyD3GnK9bcczfCMWzmt_3MKqJD09NTRaaM-Sl7QEgA9od6VzwLUARfEUjd0BrvZLbg5vsGaSnlCtBPIZoZ2ad2aAOxF9wVJRMxSrsYxDaXe_hjmhYEbU8n3LEE6RL-JXvXEENUJyN5IbePDNz6Niuy2wk5YDJ_tuZvz9IMXSjb-NoyCSiLzptmqlR09jj8TzzDnAnVe4pPYUt-lEH8eFjFG7g8lC1_GxZ5wu8')",
//                 }}
//               ></div>
//             </div>
//           </div>

//           {/* Providers Section */}
//           <div className="col-span-1 bg-white border border-gray-200 rounded-lg shadow-sm lg:col-span-2">
//             <div className="flex items-center justify-between p-4 border-b border-gray-200">
//               <h2 className="text-lg font-semibold text-gray-800">Providers</h2>
//               <button className="flex items-center gap-2 px-4 py-2 text-sm font-semibold text-white bg-blue-600 rounded-md hover:bg-blue-700">
//                 <span className="text-base material-symbols-outlined">add</span>
//                 <span>Onboard New Provider</span>
//               </button>
//             </div>
//             {/* Providers Table (same-to-same as HTML, copy rows) */}
//           </div>

//           {/* Feedback Summary */}
//           <div className="col-span-1 bg-white border border-gray-200 rounded-lg shadow-sm">
//             <div className="p-4 border-b border-gray-200">
//               <h2 className="text-lg font-semibold text-gray-800">User Feedback Summary</h2>
//             </div>
//             <div className="p-4 space-y-4">
//               <div className="flex items-center gap-2">
//                 <span className="text-3xl font-bold text-gray-800">4.6</span>
//                 <div className="flex items-center">
//                   <span className="text-yellow-400 material-symbols-outlined">star</span>
//                   <span className="text-yellow-400 material-symbols-outlined">star</span>
//                   <span className="text-yellow-400 material-symbols-outlined">star</span>
//                   <span className="text-yellow-400 material-symbols-outlined">star</span>
//                   <span className="text-yellow-400 material-symbols-outlined">star_half</span>
//                 </div>
//                 <span className="text-sm text-gray-500">from 120 reviews</span>
//               </div>
//               <p className="text-sm text-gray-600">
//                 Positive feedback highlights quick response times and helpful providers.
//                 Areas for improvement include expanding provider network in rural areas
//                 and enhancing communication during pending requests.
//               </p>
//               <button className="text-sm font-semibold text-blue-600 hover:underline">
//                 View All Feedback
//               </button>
//             </div>
//           </div>
//         </div>
//       </main>
//     </div>
//   );
// }










// "use client";

// import { useState } from "react";
// import {
//   Home,
//   Users,
//   UserCircle,
//   ListChecks,
//   MoreHorizontal,
//   Menu,
// } from "lucide-react";

// export default function AdminDashboard() {
//   const [activeTab, setActiveTab] = useState("dashboard");

//   // Dummy pages for now – replace with real ones later
//   const renderContent = () => {
//     switch (activeTab) {
//       case "dashboard":
//         return (
//           <div className="flex-grow overflow-y-auto">
//             <div className="p-4">
//               {/* Stats Cards */}
//               <div className="grid grid-cols-2 gap-4">
//                 <div className="flex flex-col gap-2 p-4 bg-white shadow-sm rounded-xl">
//                   <p className="text-[#4A5568] text-sm font-medium">Total Users</p>
//                   <p className="text-[#2B6CB0] text-3xl font-bold">1,234</p>
//                 </div>
//                 <div className="flex flex-col gap-2 p-4 bg-white shadow-sm rounded-xl">
//                   <p className="text-[#4A5568] text-sm font-medium">Providers</p>
//                   <p className="text-[#2B6CB0] text-3xl font-bold">567</p>
//                 </div>
//                 <div className="flex flex-col col-span-2 gap-2 p-4 bg-white shadow-sm rounded-xl">
//                   <p className="text-[#4A5568] text-sm font-medium">Total Requests</p>
//                   <p className="text-[#2B6CB0] text-3xl font-bold">890</p>
//                 </div>
//               </div>
//             </div>

//             {/* Requests Overview */}
//             <div className="px-4">
//               <h2 className="text-[#1A202C] text-lg font-bold tracking-tight mb-3">
//                 Requests Overview
//               </h2>
//               <div className="flex flex-col gap-4">
//                 {/* By Status */}
//                 <div className="flex flex-col gap-4 rounded-xl border border-[#E2E8F0] p-4 bg-white shadow-sm">
//                   <p className="text-[#1A202C] text-base font-semibold">By Status</p>
//                   <div className="grid grid-flow-col gap-6 grid-rows-[1fr_auto] items-end justify-items-center h-40 px-3">
//                     {/* Pending */}
//                     <div className="self-end w-full rounded-t-md bg-[#EBF8FF]" style={{ height: "20%" }}>
//                       <div className="bg-[#2B6CB0] h-full w-full rounded-t-md"></div>
//                     </div>
//                     <p className="text-[#4A5568] text-xs font-medium">Pending</p>

//                     {/* In Progress */}
//                     <div className="self-end w-full rounded-t-md bg-[#EBF8FF]" style={{ height: "60%" }}>
//                       <div className="bg-[#2B6CB0] h-full w-full rounded-t-md"></div>
//                     </div>
//                     <p className="text-[#4A5568] text-xs font-medium">In Progress</p>

//                     {/* Completed */}
//                     <div className="self-end w-full rounded-t-md bg-[#EBF8FF]" style={{ height: "10%" }}>
//                       <div className="bg-[#2B6CB0] h-full w-full rounded-t-md"></div>
//                     </div>
//                     <p className="text-[#4A5568] text-xs font-medium">Completed</p>
//                   </div>
//                 </div>

//                 {/* By Category */}
//                 <div className="flex flex-col gap-4 rounded-xl border border-[#E2E8F0] p-4 bg-white shadow-sm">
//                   <p className="text-[#1A202C] text-base font-semibold">By Category</p>
//                   <div className="grid gap-y-3 gap-x-4 grid-cols-[auto_1fr] items-center py-3">
//                     <p className="text-[#4A5568] text-xs font-medium">Plumbing</p>
//                     <div className="h-2.5 rounded-full bg-[#EBF8FF]">
//                       <div className="bg-[#2B6CB0] h-full rounded-full" style={{ width: "75%" }}></div>
//                     </div>
//                     <p className="text-[#4A5568] text-xs font-medium">Electrical</p>
//                     <div className="h-2.5 rounded-full bg-[#EBF8FF]">
//                       <div className="bg-[#2B6CB0] h-full rounded-full" style={{ width: "40%" }}></div>
//                     </div>
//                     <p className="text-[#4A5568] text-xs font-medium">Cleaning</p>
//                     <div className="h-2.5 rounded-full bg-[#EBF8FF]">
//                       <div className="bg-[#2B6CB0] h-full rounded-full" style={{ width: "90%" }}></div>
//                     </div>
//                   </div>
//                 </div>
//               </div>
//             </div>

//             {/* Service Area */}
//             <div className="p-4">
//               <h2 className="text-[#1A202C] text-lg font-bold tracking-tight mb-3">Service Area</h2>
//               <div
//                 className="w-full bg-center bg-no-repeat bg-cover shadow-sm aspect-video rounded-xl"
//                 style={{
//                   backgroundImage:
//                     "url('https://lh3.googleusercontent.com/aida-public/AB6AXuDixHJQ2adLYmh69NASDoUymEcBJnG2M0WAFaK7nyIsJlOOtY6qlMsv4Pgv-3VBgzP-lPwp96MLe5EHncgdG-FJfehlQJpcXUEnDHlhY7Ce7rmRf_utmZZgK84ArQh3gkzZFYspbKmiPcwPDw-WBOrovIRBABe5LRbyzncnUkD2cb0iCUarogf9J4caUJs_YtvA1phh8KORyKXv6EjJ_iHVPbtXgwF6m-78O1E5DboEmYPjA8wJHDylklaBHWHGILk8SQc3Etuf_RA')",
//                 }}
//               ></div>
//             </div>
//           </div>
//         );
//       case "users":
//         return <div className="p-6 text-lg font-semibold text-center">Users Management Page</div>;
//       case "providers":
//         return <div className="p-6 text-lg font-semibold text-center">Providers Management Page</div>;
//       case "requests":
//         return <div className="p-6 text-lg font-semibold text-center">Requests Management Page</div>;
//       case "more":
//         return <div className="p-6 text-lg font-semibold text-center">More Options (You’ll handle this)</div>;
//       default:
//         return null;
//     }
//   };

//   return (
//     <div className="bg-[#EBF8FF] min-h-screen flex flex-col font-['Manrope','Noto Sans',sans-serif]">
//       {/* Header */}
//       <div className="flex items-center justify-between p-4 bg-white shadow-sm">
//         <button className="text-[#1A202C]">
//           <Menu size={28} />
//         </button>
//         <h1 className="text-[#1A202C] text-xl font-bold leading-tight text-center flex-1">
//           {activeTab.charAt(0).toUpperCase() + activeTab.slice(1)}
//         </h1>
//       </div>

//       {/* Main Content */}
//       <div className="flex-grow">{renderContent()}</div>

//       {/* Bottom Navigation */}
//       <div className="sticky bottom-0">
//         <div className="flex justify-around border-t border-[#E2E8F0] bg-white py-2">
//           {[
//             { id: "dashboard", label: "Dashboard", icon: <Home size={24} /> },
//             { id: "users", label: "Users", icon: <Users size={24} /> },
//             { id: "providers", label: "Providers", icon: <UserCircle size={24} /> },
//             { id: "requests", label: "Requests", icon: <ListChecks size={24} /> },
//             { id: "more", label: "More", icon: <MoreHorizontal size={24} /> },
//           ].map((tab) => (
//             <button
//               key={tab.id}
//               onClick={() => setActiveTab(tab.id)}
//               className={`flex flex-col items-center gap-1 ${
//                 activeTab === tab.id ? "text-[#2B6CB0]" : "text-[#4A5568]"
//               }`}
//             >
//               {tab.icon}
//               <p className="text-xs font-medium">{tab.label}</p>
//             </button>
//           ))}
//         </div>
//       </div>
//     </div>
//   );
// }







// "use client";

// import { useState } from "react";
// import BottomNav from "@/components/admin/BottomNav";
// import Header from "@/components/Header";
// <Header/>

// export default function AdminDashboard() {

//   const [activeTab, setActiveTab] = useState("dashboard");

//   const renderContent = () => {
  
//     switch (activeTab) {
//       case "dashboard":
//         return (
//           <div className="flex-grow p-4 overflow-y-auto">
//             {/* Stats Cards */}
//             <div className="grid grid-cols-2 gap-4 mb-4">
//               <div className="flex flex-col gap-2 p-4 bg-white shadow-sm rounded-xl">
//                 <p className="text-[#4A5568] text-sm font-medium">Total Users</p>
//                 <p className="text-[#2B6CB0] text-3xl font-bold">1,234</p>
//               </div>
//               <div className="flex flex-col gap-2 p-4 bg-white shadow-sm rounded-xl">
//                 <p className="text-[#4A5568] text-sm font-medium">Providers</p>
//                 <p className="text-[#2B6CB0] text-3xl font-bold">567</p>
//               </div>
//               <div className="flex flex-col col-span-2 gap-2 p-4 bg-white shadow-sm rounded-xl">
//                 <p className="text-[#4A5568] text-sm font-medium">Total Requests</p>
//                 <p className="text-[#2B6CB0] text-3xl font-bold">890</p>
//               </div>
//             </div>

//             {/* Requests Overview */}
//             <div className="flex flex-col gap-4 mb-4">
//               {/* By Status */}
//               <div className="flex flex-col gap-4 rounded-xl border border-[#E2E8F0] p-4 bg-white shadow-sm">
//                 <p className="text-[#1A202C] text-base font-semibold">By Status</p>
//                 <div className="flex items-end justify-between h-40 gap-6 px-3">
//                   <div className="flex flex-col items-center">
//                     <div className="w-6 h-32 bg-[#2B6CB0] rounded-t-md"></div>
//                     <p className="text-[#4A5568] text-xs font-medium mt-1">Pending</p>
//                   </div>
//                   <div className="flex flex-col items-center">
//                     <div className="w-6 h-48 bg-[#2B6CB0] rounded-t-md"></div>
//                     <p className="text-[#4A5568] text-xs font-medium mt-1">In Progress</p>
//                   </div>
//                   <div className="flex flex-col items-center">
//                     <div className="w-6 h-16 bg-[#2B6CB0] rounded-t-md"></div>
//                     <p className="text-[#4A5568] text-xs font-medium mt-1">Completed</p>
//                   </div>
//                 </div>
//               </div>

//               {/* By Category */}
//               <div className="flex flex-col gap-4 rounded-xl border border-[#E2E8F0] p-4 bg-white shadow-sm">
//                 <p className="text-[#1A202C] text-base font-semibold">By Category</p>
//                 <div className="grid gap-y-3 gap-x-4 grid-cols-[auto_1fr] items-center py-3">
//                   <p className="text-[#4A5568] text-xs font-medium">Plumbing</p>
//                   <div className="h-2.5 rounded-full bg-[#EBF8FF]">
//                     <div className="bg-[#2B6CB0] h-full rounded-full w-3/4"></div>
//                   </div>
//                   <p className="text-[#4A5568] text-xs font-medium">Electrical</p>
//                   <div className="h-2.5 rounded-full bg-[#EBF8FF]">
//                     <div className="bg-[#2B6CB0] h-full rounded-full w-2/5"></div>
//                   </div>
//                   <p className="text-[#4A5568] text-xs font-medium">Cleaning</p>
//                   <div className="h-2.5 rounded-full bg-[#EBF8FF]">
//                     <div className="bg-[#2B6CB0] h-full rounded-full w-9/10"></div>
//                   </div>
//                 </div>
//               </div>
//             </div>

//             {/* Service Area */}
//             <div className="p-4">
//               <h2 className="text-[#1A202C] text-lg font-bold tracking-tight mb-3">Service Area</h2>
//               <div
//                 className="w-full bg-center bg-no-repeat bg-cover shadow-sm aspect-video rounded-xl"
//                 style={{
//                   backgroundImage:
//                     "url('https://lh3.googleusercontent.com/aida-public/AB6AXuDixHJQ2adLYmh69NASDoUymEcBJnG2M0WAFaK7nyIsJlOOtY6qlMsv4Pgv-3VBgzP-lPwp96MLe5EHncgdG-FJfehlQJpcXUEnDHlhY7Ce7rmRf_utmZZgK84ArQh3gkzZFYspbKmiPcwPDw-WBOrovIRBABe5LRbyzncnUkD2cb0iCUarogf9J4caUJs_YtvA1phh8KORyKXv6EjJ_iHVPbtXgwF6m-78O1E5DboEmYPjA8wJHDylklaBHWHGILk8SQc3Etuf_RA')",
//                 }}
//               ></div>
//             </div>
//           </div>
//         );
//       case "users":
//         return <div className="p-6 text-lg font-semibold text-center">Users Management Page</div>;
//       case "providers":
//         return <div className="p-6 text-lg font-semibold text-center">Providers Management Page</div>;
//       case "requests":
//         return <div className="p-6 text-lg font-semibold text-center">Requests Management Page</div>;
//       case "more":
//         return <div className="p-6 text-lg font-semibold text-center">More Options (You’ll handle this)</div>;
//       default:
//         return null;
//     }
//   };

//   return (
//     <div className="bg-[#EBF8FF] min-h-screen flex flex-col font-['Manrope','Noto Sans',sans-serif]">
//       {/* Header without Menu icon */}
//       <div className="flex items-center justify-center p-4 bg-white shadow-sm">
//         <h1 className="text-[#1A202C] text-xl font-bold leading-tight text-center flex-1">
//           {activeTab.charAt(0).toUpperCase() + activeTab.slice(1)}
//         </h1>
//       </div>

//       {/* Main Content */}
//       <div className="flex-grow">{renderContent()}</div>

//       {/* Bottom Navigation Component */}
//       {/* <BottomNav activeTab={activeTab} setActiveTab={setActiveTab} /> */}
//       <BottomNav/>
//     </div>
//   );
// }

// "use client";

// import { useState } from "react";
// import BottomNav from "@/components/admin/BottomNav";
// import Header from "@/components/Header";

// export default function AdminDashboard() {
//   const [activeTab, setActiveTab] = useState("dashboard");

//   const renderContent = () => {
//     switch (activeTab) {
//       case "dashboard":
//         return (
//           <div className="flex-grow p-4 overflow-y-auto">
//             {/* Stats Cards */}
//             <div className="grid grid-cols-2 gap-4 mb-4">
//               <div className="flex flex-col gap-2 p-4 bg-white shadow-sm rounded-xl">
//                 <p className="text-sm font-medium text-gray-600">Total Users</p>
//                 <p className="text-3xl font-bold text-blue-700">1,234</p>
//               </div>
//               <div className="flex flex-col gap-2 p-4 bg-white shadow-sm rounded-xl">
//                 <p className="text-sm font-medium text-gray-600">Providers</p>
//                 <p className="text-3xl font-bold text-blue-700">567</p>
//               </div>
//               <div className="flex flex-col col-span-2 gap-2 p-4 bg-white shadow-sm rounded-xl">
//                 <p className="text-sm font-medium text-gray-600">Total Requests</p>
//                 <p className="text-3xl font-bold text-blue-700">890</p>
//               </div>
//             </div>

//             {/* Requests Overview */}
//             <div className="flex flex-col gap-4 mb-4">
//               {/* By Status */}
//               <div className="flex flex-col gap-4 p-4 bg-white border border-gray-300 shadow-sm rounded-xl">
//                 <p className="text-base font-semibold text-gray-800">By Status</p>
//                 <div className="flex items-end justify-between h-40 gap-6 px-3">
//                   <div className="flex flex-col items-center">
//                     <div className="w-6 h-32 bg-blue-700 rounded-t-md"></div>
//                     <p className="mt-1 text-xs font-medium text-gray-500">Pending</p>
//                   </div>
//                   <div className="flex flex-col items-center">
//                     <div className="w-6 h-48 bg-blue-700 rounded-t-md"></div>
//                     <p className="mt-1 text-xs font-medium text-gray-500">In Progress</p>
//                   </div>
//                   <div className="flex flex-col items-center">
//                     <div className="w-6 h-16 bg-blue-700 rounded-t-md"></div>
//                     <p className="mt-1 text-xs font-medium text-gray-500">Completed</p>
//                   </div>
//                 </div>
//               </div>

//               {/* By Category */}
//               <div className="flex flex-col gap-4 p-4 bg-white border border-gray-300 shadow-sm rounded-xl">
//                 <p className="text-base font-semibold text-gray-800">By Category</p>
//                 <div className="grid gap-y-3 gap-x-4 grid-cols-[auto_1fr] items-center py-3">
//                   <p className="text-xs font-medium text-gray-500">Plumbing</p>
//                   <div className="h-2.5 rounded-full bg-blue-100">
//                     <div className="w-3/4 h-full bg-blue-700 rounded-full"></div>
//                   </div>
//                   <p className="text-xs font-medium text-gray-500">Electrical</p>
//                   <div className="h-2.5 rounded-full bg-blue-100">
//                     <div className="w-2/5 h-full bg-blue-700 rounded-full"></div>
//                   </div>
//                   <p className="text-xs font-medium text-gray-500">Cleaning</p>
//                   <div className="h-2.5 rounded-full bg-blue-100">
//                     <div className="h-full bg-blue-700 rounded-full w-9/10"></div>
//                   </div>
//                 </div>
//               </div>
//             </div>

//             {/* Service Area */}
//             <div className="p-4">
//               <h2 className="mb-3 text-lg font-bold tracking-tight text-gray-800">Service Area</h2>
//               <div
//                 className="w-full bg-center bg-no-repeat bg-cover shadow-sm aspect-video rounded-xl"
//                 style={{
//                   backgroundImage:
//                     "url('https://lh3.googleusercontent.com/aida-public/AB6AXuDixHJQ2adLYmh69NASDoUymEcBJnG2M0WAFaK7nyIsJlOOtY6qlMsv4Pgv-3VBgzP-lPwp96MLe5EHncgdG-FJfehlQJpcXUEnDHlhY7Ce7rmRf_utmZZgK84ArQh3gkzZFYspbKmiPcwPDw-WBOrovIRBABe5LRbyzncnUkD2cb0iCUarogf9J4caUJs_YtvA1phh8KORyKXv6EjJ_iHVPbtXgwF6m-78O1E5DboEmYPjA8wJHDylklaBHWHGILk8SQc3Etuf_RA')",
//                 }}
//               ></div>
//             </div>
//           </div>
//         );

//       case "users":
//         return <div className="p-6 text-lg font-semibold text-center">Users Management Page</div>;
//       case "providers":
//         return <div className="p-6 text-lg font-semibold text-center">Providers Management Page</div>;
//       case "requests":
//         return <div className="p-6 text-lg font-semibold text-center">Requests Management Page</div>;
//       case "more":
//         return <div className="p-6 text-lg font-semibold text-center">More Options</div>;
//       default:
//         return null;
//     }
//   };

//   return (
//     <div className="bg-[#EBF8FF] min-h-screen flex flex-col font-['Manrope','Noto Sans',sans-serif]">
//       {/* Keep your Header as-is */}
//       <Header />

//       {/* Main Content */}
//       <div className="flex-grow">{renderContent()}</div>

//       {/* Bottom Navigation */}
//       {/* Ensure BottomNav can accept these props */}
//      <BottomNav/>
//     </div>
//   );
// }



"use client";

import { useState } from "react";
import BottomNav from "@/components/admin/BottomNav";
import Header from "@/components/Header";

export default function AdminDashboard() {
  const [activeTab, setActiveTab] = useState("dashboard");

  const renderContent = () => {
    switch (activeTab) {
      case "dashboard":
        return (
          <div className="flex-grow p-4 overflow-y-auto">
            {/* Stats Cards */}
            <div className="grid grid-cols-1 gap-4 mb-4 sm:grid-cols-2">
              <div className="flex flex-col gap-2 p-4 bg-white shadow-sm rounded-xl">
                <p className="text-sm font-medium text-gray-600">Total Users</p>
                <p className="text-3xl font-bold text-blue-700">1,234</p>
              </div>
              <div className="flex flex-col gap-2 p-4 bg-white shadow-sm rounded-xl">
                <p className="text-sm font-medium text-gray-600">Providers</p>
                <p className="text-3xl font-bold text-blue-700">567</p>
              </div>
              <div className="flex flex-col gap-2 p-4 bg-white shadow-sm sm:col-span-2 rounded-xl">
                <p className="text-sm font-medium text-gray-600">Total Requests</p>
                <p className="text-3xl font-bold text-blue-700">890</p>
              </div>
            </div>

            {/* Requests Overview */}
            <div className="flex flex-col gap-4 mb-4">
              {/* By Status */}
              <div className="flex flex-col gap-4 p-4 bg-white border border-gray-300 shadow-sm rounded-xl">
                <p className="text-base font-semibold text-gray-800">By Status</p>
                <div className="flex items-end justify-between gap-6">
                  {[
                    { label: "Pending", height: "h-24" },
                    { label: "In Progress", height: "h-40" },
                    { label: "Completed", height: "h-16" },
                  ].map((item) => (
                    <div key={item.label} className="flex flex-col items-center">
                      <div
                        className={`w-6 ${item.height} sm:h-32 bg-blue-700 rounded-t-md transition-all duration-300`}
                      ></div>
                      <p className="mt-1 text-xs font-medium text-gray-500">{item.label}</p>
                    </div>
                  ))}
                </div>
              </div>

              {/* By Category */}
              <div className="flex flex-col gap-4 p-4 bg-white border border-gray-300 shadow-sm rounded-xl">
                <p className="text-base font-semibold text-gray-800">By Category</p>
                <div className="grid gap-y-3 gap-x-4 grid-cols-1 sm:grid-cols-[auto_1fr] items-center py-3">
                  {[
                    { label: "Plumbing", width: "w-3/4" },
                    { label: "Electrical", width: "w-2/5" },
                    { label: "Cleaning", width: "w-[90%]" },
                  ].map((item) => (
                    <div key={item.label} className="flex flex-col gap-1 sm:flex-row sm:items-center">
                      <p className="text-xs font-medium text-gray-500">{item.label}</p>
                      <div className="flex-1 h-2.5 rounded-full bg-blue-100">
                        <div className={`${item.width} h-full bg-blue-700 rounded-full`}></div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Service Area */}
            <div className="p-4">
              <h2 className="mb-3 text-lg font-bold tracking-tight text-gray-800">Service Area</h2>
              <div
                className="w-full bg-center bg-no-repeat bg-cover shadow-sm aspect-video rounded-xl min-h-[200px] sm:min-h-[300px]"
                style={{
                  backgroundImage:
                    "url('https://lh3.googleusercontent.com/aida-public/AB6AXuDixHJQ2adLYmh69NASDoUymEcBJnG2M0WAFaK7nyIsJlOOtY6qlMsv4Pgv-3VBgzP-lPwp96MLe5EHncgdG-FJfehlQJpcXUEnDHlhY7Ce7rmRf_utmZZgK84ArQh3gkzZFYspbKmiPcwPDw-WBOrovIRBABe5LRbyzncnUkD2cb0iCUarogf9J4caUJs_YtvA1phh8KORyKXv6EjJ_iHVPbtXgwF6m-78O1E5DboEmYPjA8wJHDylklaBHWHGILk8SQc3Etuf_RA')",
                }}
              ></div>
            </div>
          </div>
        );

      case "users":
        return <div className="p-6 text-lg font-semibold text-center">Users Management Page</div>;
      case "providers":
        return <div className="p-6 text-lg font-semibold text-center">Providers Management Page</div>;
      case "requests":
        return <div className="p-6 text-lg font-semibold text-center">Requests Management Page</div>;
      case "more":
        return <div className="p-6 text-lg font-semibold text-center">More Options</div>;
      default:
        return null;
    }
  };

  return (
    <div className="bg-[#EBF8FF] min-h-screen flex flex-col font-['Manrope','Noto Sans',sans-serif]">
      <Header />
      <div className="flex-grow">{renderContent()}</div>
      <BottomNav />
    </div>
  );
}

