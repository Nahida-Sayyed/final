// "use client";

// import { useEffect, useState } from "react";
// import { db } from "../../lib/firebase";
// import { collection, onSnapshot, doc, deleteDoc } from "firebase/firestore";

// export default function AdminUsers() {
//   const [users, setUsers] = useState<Array<any>>([]);

//   useEffect(() => {
//     const unsub = onSnapshot(collection(db, "users"), (snap) => {
//       const list: Array<any> = [];
//       snap.forEach((doc) => list.push({ id: doc.id, ...doc.data() }));
//       setUsers(list);
//     });
//     return () => unsub();
//   }, []);

//   const handleDelete = async (id: string) => {
//     if (confirm("Are you sure you want to delete this user?")) {
//       await deleteDoc(doc(db, "users", id));
//       alert("User deleted!");
//     }
//   };

//   return (
//     <div className="flex flex-col gap-4">
//       <h1 className="text-3xl font-bold text-blue-600">Users Management</h1>
//       {users.map((user) => (
//         <div
//           key={user.id}
//           className="flex items-center justify-between p-4 bg-white shadow-md rounded-xl"
//         >
//           <div>
//             <p><strong>Name:</strong> {user.name}</p>
//             <p><strong>Phone:</strong> {user.phone}</p>
//             <p><strong>Roles:</strong> {user.roles?.join(", ")}</p>
//           </div>
//           <button
//             onClick={() => handleDelete(user.id)}
//             className="px-4 py-2 text-white bg-red-600 rounded hover:bg-red-700"
//           >
//             Delete
//           </button>
//         </div>
//       ))}
//     </div>
//   );
// }





// "use client";

// import { useState } from "react";
// import {
//   Home,
//   Users,
//   UserCircle,
//   ListChecks,
//   MoreHorizontal,
//   Menu,
//   MoreVertical,
// } from "lucide-react";
// import BottomNav from "@/components/admin/BottomNav";

// export default function AdminUsersPage() {
//   const [activeTab, setActiveTab] = useState("users");

//   const users = [
//     {
//       id: "12345",
//       name: "Ethan Carter",
//       contact: "555-0101",
//       location: "New York",
//       requests: 12,
//       status: "Active",
//     },
//     {
//       id: "67890",
//       name: "Olivia Bennett",
//       contact: "olivia.b@mail.com",
//       location: "Los Angeles",
//       requests: 5,
//       status: "Blocked",
//     },
//     {
//       id: "24680",
//       name: "Noah Thompson",
//       contact: "555-0102",
//       location: "Chicago",
//       requests: 8,
//       status: "Active",
//     },
//     {
//       id: "13579",
//       name: "Ava Martinez",
//       contact: "ava.m@mail.com",
//       location: "Houston",
//       requests: 20,
//       status: "Active",
//     },
//     {
//       id: "97531",
//       name: "Liam Harris",
//       contact: "555-0103",
//       location: "Phoenix",
//       requests: 15,
//       status: "Blocked",
//     },
//   ];

//   return (
//     <div className="flex flex-col min-h-screen bg-[#F8FAFC]">
//       {/* Header */}
//       <header className="sticky top-0 z-10 flex items-center justify-between p-4 bg-white border-b border-gray-200 shadow-sm">
//         <button className="text-[#2A6293]">
//           <Menu size={28} />
//         </button>
//         <h1 className="text-xl font-bold text-[#0D141C]">Users</h1>
//         <div className="w-7" />
//       </header>

//       {/* Main Content */}
//       <main className="flex-grow p-4 overflow-x-auto">
//         <div className="overflow-hidden bg-white shadow-sm rounded-xl">
//           <table className="min-w-full text-sm">
//             <thead className="text-gray-900 bg-gray-50">
//               <tr>
//                 <th className="px-4 py-3 font-semibold text-left">User ID</th>
//                 <th className="px-4 py-3 font-semibold text-left">Name</th>
//                 <th className="px-4 py-3 font-semibold text-left">Phone/Email</th>
//                 <th className="px-4 py-3 font-semibold text-left">Location</th>
//                 <th className="px-4 py-3 font-semibold text-center">Total Requests</th>
//                 <th className="px-4 py-3 font-semibold text-left">Status</th>
//                 <th className="px-4 py-3 font-semibold text-right">Actions</th>
//               </tr>
//             </thead>
//             <tbody className="divide-y divide-gray-200">
//               {users.map((user) => (
//                 <tr key={user.id} className="hover:bg-gray-50">
//                   <td className="px-4 py-4 font-medium text-gray-900">{user.id}</td>
//                   <td className="px-4 py-4 text-gray-700">{user.name}</td>
//                   <td className="px-4 py-4 text-gray-700">{user.contact}</td>
//                   <td className="px-4 py-4 text-gray-700">{user.location}</td>
//                   <td className="px-4 py-4 text-center text-gray-700">
//                     {user.requests}
//                   </td>
//                   <td className="px-4 py-4">
//                     {user.status === "Active" ? (
//                       <span className="inline-flex items-center px-2 py-1 text-xs font-medium text-green-700 rounded-md bg-green-50 ring-1 ring-green-600/20">
//                         Active
//                       </span>
//                     ) : (
//                       <span className="inline-flex items-center px-2 py-1 text-xs font-medium text-red-700 rounded-md bg-red-50 ring-1 ring-red-600/20">
//                         Blocked
//                       </span>
//                     )}
//                   </td>
//                   <td className="px-4 py-4 text-right">
//                     <button className="text-[#2A6293] hover:text-blue-800">
//                       <MoreVertical size={20} />
//                     </button>
//                   </td>
//                 </tr>
//               ))}
//             </tbody>
//           </table>
//         </div>
//       </main>

//       {/* Bottom Navigation */}
//       <footer className="sticky bottom-0 bg-white border-t border-gray-200">
//         {/* <nav className="flex justify-around py-2">
//           <button
//             onClick={() => setActiveTab("dashboard")}
//             className={`flex flex-col items-center gap-1 ${
//               activeTab === "dashboard" ? "text-[#2A6293]" : "text-gray-500"
//             }`}
//           >
//             <Home size={22} />
//             <span className="text-xs">Dashboard</span>
//           </button>

//           <button
//             onClick={() => setActiveTab("users")}
//             className={`flex flex-col items-center gap-1 ${
//               activeTab === "users" ? "text-[#2A6293]" : "text-gray-500"
//             }`}
//           >
//             <Users size={22} />
//             <span className="text-xs font-bold">Users</span>
//           </button>

//           <button
//             onClick={() => setActiveTab("providers")}
//             className={`flex flex-col items-center gap-1 ${
//               activeTab === "providers" ? "text-[#2A6293]" : "text-gray-500"
//             }`}
//           >
//             <UserCircle size={22} />
//             <span className="text-xs">Providers</span>
//           </button>

//           <button
//             onClick={() => setActiveTab("requests")}
//             className={`flex flex-col items-center gap-1 ${
//               activeTab === "requests" ? "text-[#2A6293]" : "text-gray-500"
//             }`}
//           >
//             <ListChecks size={22} />
//             <span className="text-xs">Requests</span>
//           </button>

//           <button
//             onClick={() => setActiveTab("more")}
//             className={`flex flex-col items-center gap-1 ${
//               activeTab === "more" ? "text-[#2A6293]" : "text-gray-500"
//             }`}
//           >
//             <MoreHorizontal size={22} />
//             <span className="text-xs">More</span>
//           </button>
//         </nav> */}
//         <BottomNav/>
//       </footer>
//     </div>
//   );
// }




// "use client";

// import { useState } from "react";
// import { MoreVertical } from "lucide-react";
// import BottomNav from "@/components/admin/BottomNav";

// export default function AdminUsersPage() {
//   const [activeTab] = useState("users");

//   const users = [
//     {
//       id: "12345",
//       name: "Ethan Carter",
//       contact: "555-0101",
//       location: "New York",
//       requests: 12,
//       status: "Active",
//     },
//     {
//       id: "67890",
//       name: "Olivia Bennett",
//       contact: "olivia.b@mail.com",
//       location: "Los Angeles",
//       requests: 5,
//       status: "Blocked",
//     },
//     {
//       id: "24680",
//       name: "Noah Thompson",
//       contact: "555-0102",
//       location: "Chicago",
//       requests: 8,
//       status: "Active",
//     },
//     {
//       id: "13579",
//       name: "Ava Martinez",
//       contact: "ava.m@mail.com",
//       location: "Houston",
//       requests: 20,
//       status: "Active",
//     },
//     {
//       id: "97531",
//       name: "Liam Harris",
//       contact: "555-0103",
//       location: "Phoenix",
//       requests: 15,
//       status: "Blocked",
//     },
//   ];

//   return (
//     <div className="flex flex-col min-h-screen bg-[#EAF4FB]"> 
//       {/* Header */}
//       <header className="sticky top-0 z-10 flex items-center justify-center px-4 py-3 bg-white border-b border-gray-200 shadow-sm">
//         <h1 className="text-lg sm:text-xl font-bold text-[#0D141C]">Users</h1>
//       </header>

//       {/* Main Content */}
//       <main className="flex-grow p-4 pb-24">
//         <div className="overflow-x-auto bg-white shadow-sm rounded-xl">
//           <table className="min-w-full text-sm">
//             <thead className="text-[#0D141C] bg-[#D5E9F6]">
//               <tr>
//                 <th className="px-4 py-3 font-semibold text-left">User ID</th>
//                 <th className="px-4 py-3 font-semibold text-left">Name</th>
//                 <th className="px-4 py-3 font-semibold text-left">Phone/Email</th>
//                 <th className="px-4 py-3 font-semibold text-left">Location</th>
//                 <th className="px-4 py-3 font-semibold text-center">Requests</th>
//                 <th className="px-4 py-3 font-semibold text-left">Status</th>
//                 <th className="px-4 py-3 font-semibold text-right">Actions</th>
//               </tr>
//             </thead>
//             <tbody className="divide-y divide-gray-100">
//               {users.map((user) => (
//                 <tr key={user.id} className="hover:bg-[#F1F9FF] transition">
//                   <td className="px-4 py-4 font-medium text-gray-900">{user.id}</td>
//                   <td className="px-4 py-4 text-gray-700">{user.name}</td>
//                   <td className="px-4 py-4 text-gray-700">{user.contact}</td>
//                   <td className="px-4 py-4 text-gray-700">{user.location}</td>
//                   <td className="px-4 py-4 text-center text-gray-700">{user.requests}</td>
//                   <td className="px-4 py-4">
//                     {user.status === "Active" ? (
//                       <span className="inline-flex items-center px-2 py-1 text-xs font-medium text-green-700 rounded-lg bg-green-50 ring-1 ring-green-600/20">
//                         Active
//                       </span>
//                     ) : (
//                       <span className="inline-flex items-center px-2 py-1 text-xs font-medium text-red-700 rounded-lg bg-red-50 ring-1 ring-red-600/20">
//                         Blocked
//                       </span>
//                     )}
//                   </td>
//                   <td className="px-4 py-4 text-right">
//                     <button className="text-[#2A6293] hover:text-[#18405e] transition-colors">
//                       <MoreVertical size={20} />
//                     </button>
//                   </td>
//                 </tr>
//               ))}
//             </tbody>
//           </table>
//         </div>
//       </main>

//       {/* Bottom Navigation */}
//       <footer className="sticky bottom-0">
//         <BottomNav />
//       </footer>
//     </div>
//   );
// }


// "use client";

// import { useState } from "react";
// import { MoreVertical } from "lucide-react";
// import BottomNav from "@/components/admin/BottomNav";
// import Header from "@/components/Header";

// export default function AdminUsersPage() {
 
//   const [activeTab] = useState("users");

//   const users = [
//     {
//       id: "10001",
//       name: "Ramesh Patil",
//       contact: "9867-112233",
//       location: "Ratnagiri, Konkan",
//       requests: 8,
//       status: "Active",
//     },
//     {
//       id: "10002",
//       name: "Sunita Deshmukh",
//       contact: "sunita.d@mail.com",
//       location: "Chiplun, Konkan",
//       requests: 4,
//       status: "Blocked",
//     },
//     {
//       id: "10003",
//       name: "Mahesh Sawant",
//       contact: "9850-445566",
//       location: "Sindhudurg, Konkan",
//       requests: 12,
//       status: "Active",
//     },
//     {
//       id: "10004",
//       name: "Aarti Jadhav",
//       contact: "aarti.j@mail.com",
//       location: "Dapoli, Konkan",
//       requests: 6,
//       status: "Active",
//     },
//     {
//       id: "10005",
//       name: "Vijay Pawar",
//       contact: "9876-778899",
//       location: "Kudal, Konkan",
//       requests: 10,
//       status: "Blocked",
//     },
//   ];

//   return (
//     <div className="flex flex-col min-h-screen bg-[#EAF4FB]">
//       {/* Header */}
//          <Header/>
//       <header className="sticky top-0 z-10 flex items-center justify-center px-4 py-3 bg-white border-b border-gray-200 shadow-sm">
//         <h1 className="text-lg sm:text-xl font-bold text-[#0D141C]">Users</h1>
//       </header>

//       {/* Main Content */}
//       <main className="flex-grow p-4 pb-24">
//         <div className="overflow-x-auto bg-white shadow-sm rounded-xl">
//           <table className="min-w-full text-sm">
//             <thead className="text-[#0D141C] bg-[#D5E9F6]">
//               <tr>
//                 <th className="px-4 py-3 font-semibold text-left">User ID</th>
//                 <th className="px-4 py-3 font-semibold text-left">Name</th>
//                 <th className="px-4 py-3 font-semibold text-left">Phone/Email</th>
//                 <th className="px-4 py-3 font-semibold text-left">Location</th>
//                 <th className="px-4 py-3 font-semibold text-center">Requests</th>
//                 <th className="px-4 py-3 font-semibold text-left">Status</th>
//                 <th className="px-4 py-3 font-semibold text-right">Actions</th>
//               </tr>
//             </thead>
//             <tbody className="divide-y divide-gray-100">
//               {users.map((user) => (
//                 <tr
//                   key={user.id}
//                   className="group transition-colors hover:bg-[#2A6293] hover:text-white"
//                 >
//                   <td className="px-4 py-4 font-medium">{user.id}</td>
//                   <td className="px-4 py-4">{user.name}</td>
//                   <td className="px-4 py-4">{user.contact}</td>
//                   <td className="px-4 py-4">{user.location}</td>
//                   <td className="px-4 py-4 text-center">{user.requests}</td>
//                   <td className="px-4 py-4">
//                     {user.status === "Active" ? (
//                       <span className="inline-flex items-center px-2 py-1 text-xs font-medium text-green-700 rounded-lg bg-green-50 ring-1 ring-green-600/20 group-hover:bg-green-600 group-hover:text-white">
//                         Active
//                       </span>
//                     ) : (
//                       <span className="inline-flex items-center px-2 py-1 text-xs font-medium text-red-700 rounded-lg bg-red-50 ring-1 ring-red-600/20 group-hover:bg-red-600 group-hover:text-white">
//                         Blocked
//                       </span>
//                     )}
//                   </td>
//                   <td className="px-4 py-4 text-right">
//                     {/* FIXED: always visible + changes to white on row hover */}
//                     <button className="p-1.5 rounded-md transition-colors text-[#2A6293] group-hover:text-white hover:bg-[#2A6293] hover:text-white">
//                       <MoreVertical size={20} strokeWidth={2} />
//                     </button>
//                   </td>
//                 </tr>
//               ))}
//             </tbody>
//           </table>
//         </div>
//       </main>

//       {/* Bottom Navigation */}
//   <footer className="sticky bottom-0">
//           <BottomNav />
//         </footer>
//     </div>
//   );
// }



// "use client";

// import { MoreVertical } from "lucide-react";
// import BottomNav from "@/components/admin/BottomNav";
// import Header from "@/components/Header";

// export default function AdminUsersPage() {
//   const users = [
//     { id: "10001", name: "Ramesh Patil", contact: "9867-112233", location: "Ratnagiri, Konkan", requests: 8, status: "Active" },
//     { id: "10002", name: "Sunita Deshmukh", contact: "sunita.d@mail.com", location: "Chiplun, Konkan", requests: 4, status: "Blocked" },
//     { id: "10003", name: "Mahesh Sawant", contact: "9850-445566", location: "Sindhudurg, Konkan", requests: 12, status: "Active" },
//     { id: "10004", name: "Aarti Jadhav", contact: "aarti.j@mail.com", location: "Dapoli, Konkan", requests: 6, status: "Active" },
//     { id: "10005", name: "Vijay Pawar", contact: "9876-778899", location: "Kudal, Konkan", requests: 10, status: "Blocked" },
//   ];

//   return (
//     <div className="flex flex-col min-h-screen bg-[#EAF4FB]">
//       {/* Header */}
//       <Header />
//       <header className="sticky top-0 z-10 flex items-center justify-center px-4 py-3 bg-white border-b border-gray-200 shadow-sm">
//         <h1 className="text-lg sm:text-xl font-bold text-[#0D141C]">Users</h1>
//       </header>

//       {/* Main Content */}
//       <main className="flex-grow p-4 space-y-4 overflow-auto">
//         {/* Desktop Table */}
//         <div className="hidden overflow-x-auto bg-white shadow-sm md:block rounded-xl">
//           <table className="min-w-full text-sm">
//             <thead className="text-[#0D141C] bg-[#D5E9F6]">
//               <tr>
//                 <th className="px-4 py-3 font-semibold text-left">User ID</th>
//                 <th className="px-4 py-3 font-semibold text-left">Name</th>
//                 <th className="px-4 py-3 font-semibold text-left">Phone/Email</th>
//                 <th className="px-4 py-3 font-semibold text-left">Location</th>
//                 <th className="px-4 py-3 font-semibold text-center">Requests</th>
//                 <th className="px-4 py-3 font-semibold text-left">Status</th>
//                 <th className="px-4 py-3 font-semibold text-right">Actions</th>
//               </tr>
//             </thead>
//             <tbody className="divide-y divide-gray-100">
//               {users.map((user) => (
//                 <tr
//                   key={user.id}
//                   className="group transition-colors hover:bg-[#2A6293] hover:text-white"
//                 >
//                   <td className="px-4 py-4 font-medium">{user.id}</td>
//                   <td className="px-4 py-4">{user.name}</td>
//                   <td className="px-4 py-4">{user.contact}</td>
//                   <td className="px-4 py-4">{user.location}</td>
//                   <td className="px-4 py-4 text-center">{user.requests}</td>
//                   <td className="px-4 py-4">
//                     <span
//                       className={`inline-flex items-center px-2 py-1 text-xs font-medium rounded-lg ${
//                         user.status === "Active"
//                           ? "text-green-700 bg-green-50 ring-1 ring-green-600/20 group-hover:bg-green-600 group-hover:text-white"
//                           : "text-red-700 bg-red-50 ring-1 ring-red-600/20 group-hover:bg-red-600 group-hover:text-white"
//                       }`}
//                     >
//                       {user.status}
//                     </span>
//                   </td>
//                   <td className="px-4 py-4 text-right">
//                     <button className="p-1.5 rounded-md transition-colors text-[#2A6293] group-hover:text-white hover:bg-[#2A6293] hover:text-white">
//                       <MoreVertical size={20} strokeWidth={2} />
//                     </button>
//                   </td>
//                 </tr>
//               ))}
//             </tbody>
//           </table>
//         </div>

//         {/* Mobile Cards */}
//         <div className="flex flex-col gap-4 md:hidden">
//           {users.map((user) => (
//             <div key={user.id} className="bg-white shadow-sm rounded-xl p-4 flex flex-col gap-2 group hover:bg-[#2A6293] hover:text-white transition-colors">
//               <div className="flex items-center justify-between">
//                 <p className="font-semibold">{user.name}</p>
//                 <button className="p-1.5 rounded-md text-[#2A6293] group-hover:text-white hover:bg-[#2A6293] hover:text-white">
//                   <MoreVertical size={20} strokeWidth={2} />
//                 </button>
//               </div>
//               <p className="text-sm text-gray-700 group-hover:text-white">ID: {user.id}</p>
//               <p className="text-sm text-gray-700 group-hover:text-white">Contact: {user.contact}</p>
//               <p className="text-sm text-gray-700 group-hover:text-white">Location: {user.location}</p>
//               <p className="text-sm text-gray-700 group-hover:text-white">Requests: {user.requests}</p>
//               <span
//                 className={`inline-block px-2 py-1 text-xs font-medium rounded-lg ${
//                   user.status === "Active"
//                     ? "text-green-700 bg-green-50 ring-1 ring-green-600/20 group-hover:bg-green-600 group-hover:text-white"
//                     : "text-red-700 bg-red-50 ring-1 ring-red-600/20 group-hover:bg-red-600 group-hover:text-white"
//                 }`}
//               >
//                 {user.status}
//               </span>
//             </div>
//           ))}
//         </div>
//       </main>

//       {/* Bottom Navigation */}
//       <div className="sticky bottom-0">
//         <BottomNav />
//       </div>
//     </div>
//   );
// }



"use client";

import { useState, useRef, useEffect } from "react";
import { MoreVertical } from "lucide-react";
import BottomNav from "@/components/admin/BottomNav";
import Header from "@/components/Header";
import ViewDetails from "./actions/ViewDetails";
import Edit from "./actions/Edit";
import BlockUnblock from "./actions/BlockUnblock";
import DeleteUser from "./actions/DeleteUser";
import ViewRequests from "./actions/ViewRequests";
import { User } from "./types";

export default function AdminUsersPage() {
  const [users, setUsers] = useState<User[]>([
    { id: "10001", name: "Ramesh Patil", contact: "9867-112233", location: "Ratnagiri, Konkan", requests: 8, status: "Active" },
    { id: "10002", name: "Sunita Deshmukh", contact: "sunita.d@mail.com", location: "Chiplun, Konkan", requests: 4, status: "Blocked" },
    { id: "10003", name: "Mahesh Sawant", contact: "9850-445566", location: "Sindhudurg, Konkan", requests: 12, status: "Active" },
    { id: "10004", name: "Aarti Jadhav", contact: "aarti.j@mail.com", location: "Dapoli, Konkan", requests: 6, status: "Active" },
    { id: "10005", name: "Vijay Pawar", contact: "9876-778899", location: "Kudal, Konkan", requests: 10, status: "Blocked" },
  ]);

  const [dropdownOpen, setDropdownOpen] = useState<string | null>(null);
  const dropdownRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setDropdownOpen(null);
      }
    }
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  const handleToggleStatus = (userId: string, newStatus: "Active" | "Blocked") => {
    setUsers((prev) => prev.map((u) => (u.id === userId ? { ...u, status: newStatus } : u)));
  };

  const handleSaveEdit = (updatedUser: User) => {
    setUsers((prev) => prev.map((u) => (u.id === updatedUser.id ? updatedUser : u)));
  };

  const handleDelete = (userId: string) => {
    setUsers((prev) => prev.filter((u) => u.id !== userId));
  };

  return (
    <div className="flex flex-col min-h-screen bg-[#EAF4FB] font-['Manrope','Noto Sans',sans-serif]">
      <Header />

      <header className="sticky top-0 z-10 flex items-center justify-center px-4 py-3 bg-white border-b border-gray-200 shadow-sm">
        <h1 className="text-lg sm:text-xl font-bold text-[#0D141C]">Users</h1>
      </header>

      <main className="flex-grow p-4 overflow-auto">
        <div className="flex flex-col gap-4">
          {users.map((user) => (
            <div
              key={user.id}
              className="bg-white rounded-xl shadow-sm p-4 flex flex-col md:flex-row md:items-center justify-between gap-2 group hover:bg-[#2A6293] hover:text-white transition-colors relative"
            >
              {/* User Info */}
              <div className="flex flex-col flex-wrap flex-1 md:flex-row md:items-center md:gap-4">
                <p className="font-medium">{user.name}</p>
                <p className="text-sm text-gray-700 group-hover:text-white">ID: {user.id}</p>
                <p className="text-sm text-gray-700 group-hover:text-white">Contact: {user.contact}</p>
                <p className="text-sm text-gray-700 group-hover:text-white">Location: {user.location}</p>
                <p className="text-sm text-gray-700 group-hover:text-white">Requests: {user.requests}</p>
                <span
                  className={`inline-block px-2 py-1 text-xs font-medium rounded-lg ${
                    user.status === "Active"
                      ? "text-green-700 bg-green-50 ring-1 ring-green-600/20 group-hover:bg-green-600 group-hover:text-white"
                      : "text-red-700 bg-red-50 ring-1 ring-red-600/20 group-hover:bg-red-600 group-hover:text-white"
                  }`}
                >
                  {user.status}
                </span>
              </div>

              {/* Actions Dropdown */}
              <div className="relative">
                {/* Use div instead of button to avoid nested button issue */}
                <div
                  className="p-1.5 rounded-md text-[#2A6293] hover:bg-[#2A6293] hover:text-white cursor-pointer transition-colors flex items-center justify-center"
                  onClick={() => setDropdownOpen(dropdownOpen === user.id ? null : user.id)}
                >
                  <MoreVertical size={20} strokeWidth={2} />
                </div>

                {dropdownOpen === user.id && (
                  <div
                    ref={dropdownRef}
                    className="absolute right-0 z-50 w-56 mt-2 overflow-hidden bg-white border border-gray-200 rounded-lg shadow-lg"
                  >
                    <div className="flex flex-col divide-y divide-gray-100">
                      <div className="px-4 py-2">
                        <ViewDetails user={user} />
                      </div>
                      <div className="px-4 py-2">
                        <Edit user={user} onSave={handleSaveEdit} />
                      </div>
                      <div className="px-4 py-2">
                        <BlockUnblock user={user} onToggle={(status) => handleToggleStatus(user.id, status)} />
                      </div>
                      <div className="px-4 py-2">
                        <DeleteUser user={user} onDelete={() => handleDelete(user.id)} />
                      </div>
                      <div className="px-4 py-2">
                        <ViewRequests user={user} />
                      </div>
                    </div>
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>
      </main>

      {/* Sticky Bottom Nav */}
      <div className="sticky bottom-0 z-20 w-full">
        <BottomNav />
      </div>
    </div>
  );
}
