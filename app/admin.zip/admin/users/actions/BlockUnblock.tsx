"use client";

import { User } from "../types";

interface Props {
  user: User;
  onToggle: (newStatus: "Active" | "Blocked") => void;
}

export default function BlockUnblock({ user, onToggle }: Props) {
  const isActive = user.status === "Active";
  return (
    <button
      className={`p-1 rounded ${isActive ? "bg-red-600 text-white" : "bg-green-600 text-white"}`}
      onClick={() => onToggle(isActive ? "Blocked" : "Active")}
    >
      {isActive ? "Block User" : "Unblock User"}
    </button>
  );
}
