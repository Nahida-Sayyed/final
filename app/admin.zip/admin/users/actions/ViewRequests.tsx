"use client";

import { User } from "../types";

interface Props {
  user: User;
}

export default function ViewRequests({ user }: Props) {
  return (
    <div className="p-2 border-t">
      <h3 className="text-sm font-semibold">Requests for {user.name}</h3>
      <p>Total Requests: {user.requests}</p>
    </div>
  );
}
