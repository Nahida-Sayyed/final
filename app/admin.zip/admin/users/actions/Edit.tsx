"use client";

import { useState } from "react";
import { User } from "../types";

interface Props {
  user: User;
  onSave: (updatedUser: User) => void;
}

export default function Edit({ user, onSave }: Props) {
  const [name, setName] = useState(user.name);
  const [contact, setContact] = useState(user.contact);

  return (
    <div className="flex flex-col gap-1 p-2 border-b">
      <input
        className="w-full p-1 border rounded"
        value={name}
        onChange={(e) => setName(e.target.value)}
        placeholder="Name"
      />
      <input
        className="w-full p-1 border rounded"
        value={contact}
        onChange={(e) => setContact(e.target.value)}
        placeholder="Contact"
      />
      <button
        className="p-1 mt-1 text-white bg-blue-700 rounded hover:bg-blue-800"
        onClick={() => onSave({ ...user, name, contact })}
      >
        Save
      </button>
    </div>
  );
}
