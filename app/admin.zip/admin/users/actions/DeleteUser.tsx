"use client";

import { User } from "../types";

interface Props {
  user: User;
  onDelete: () => void;
}

export default function DeleteUser({ user, onDelete }: Props) {
  return (
    <button
      className="p-1 text-white bg-red-600 rounded hover:bg-red-700"
      onClick={onDelete}
    >
      Delete User
    </button>
  );
}
