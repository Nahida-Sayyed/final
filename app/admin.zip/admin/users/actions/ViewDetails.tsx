"use client";

import React from "react";

interface User {
  id: string;
  name: string;
  contact: string;
  location?: string;
  requests?: number;
  status?: string;
}

interface Props {
  user: User;
}

export default function ViewDetails({ user }: Props) {
  return (
    <div className="p-4">
      <h2 className="mb-2 text-lg font-bold">User Details</h2>
      <p><strong>ID:</strong> {user.id}</p>
      <p><strong>Name:</strong> {user.name}</p>
      <p><strong>Contact:</strong> {user.contact}</p>
      <p><strong>Location:</strong> {user.location || "N/A"}</p>
      <p><strong>Requests:</strong> {user.requests ?? 0}</p>
      <p><strong>Status:</strong> {user.status || "N/A"}</p>
    </div>
  );
}

