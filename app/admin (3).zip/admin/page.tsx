
"use client";

import { useState } from "react";
import BottomNav from "@/components/admin/BottomNav";
import Header from "@/components/Header";

export default function AdminDashboard() {
  const [activeTab, setActiveTab] = useState("dashboard");

  const renderContent = () => {
    switch (activeTab) {
      case "dashboard":
        return (
          <div className="flex-grow p-4 overflow-y-auto">
            {/* Stats Cards */}
            <div className="grid grid-cols-1 gap-4 mb-4 sm:grid-cols-2">
              <div className="flex flex-col gap-2 p-4 bg-white shadow-sm rounded-xl">
                <p className="text-sm font-medium text-gray-600">Total Users</p>
                <p className="text-3xl font-bold text-blue-700">1,234</p>
              </div>
              <div className="flex flex-col gap-2 p-4 bg-white shadow-sm rounded-xl">
                <p className="text-sm font-medium text-gray-600">Providers</p>
                <p className="text-3xl font-bold text-blue-700">567</p>
              </div>
              <div className="flex flex-col gap-2 p-4 bg-white shadow-sm sm:col-span-2 rounded-xl">
                <p className="text-sm font-medium text-gray-600">Total Requests</p>
                <p className="text-3xl font-bold text-blue-700">890</p>
              </div>
            </div>

            {/* Requests Overview */}
            <div className="flex flex-col gap-4 mb-4">
              {/* By Status */}
              <div className="flex flex-col gap-4 p-4 bg-white border border-gray-300 shadow-sm rounded-xl">
                <p className="text-base font-semibold text-gray-800">By Status</p>
                <div className="flex items-end justify-between gap-6">
                  {[
                    { label: "Pending", height: "h-24" },
                    { label: "In Progress", height: "h-40" },
                    { label: "Completed", height: "h-16" },
                  ].map((item) => (
                    <div key={item.label} className="flex flex-col items-center">
                      <div
                        className={`w-6 ${item.height} sm:h-32 bg-blue-700 rounded-t-md transition-all duration-300`}
                      ></div>
                      <p className="mt-1 text-xs font-medium text-gray-500">{item.label}</p>
                    </div>
                  ))}
                </div>
              </div>

              {/* By Category */}
              <div className="flex flex-col gap-4 p-4 bg-white border border-gray-300 shadow-sm rounded-xl">
                <p className="text-base font-semibold text-gray-800">By Category</p>
                <div className="grid gap-y-3 gap-x-4 grid-cols-1 sm:grid-cols-[auto_1fr] items-center py-3">
                  {[
                    { label: "Plumbing", width: "w-3/4" },
                    { label: "Electrical", width: "w-2/5" },
                    { label: "Cleaning", width: "w-[90%]" },
                  ].map((item) => (
                    <div key={item.label} className="flex flex-col gap-1 sm:flex-row sm:items-center">
                      <p className="text-xs font-medium text-gray-500">{item.label}</p>
                      <div className="flex-1 h-2.5 rounded-full bg-blue-100">
                        <div className={`${item.width} h-full bg-blue-700 rounded-full`}></div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Service Area */}
            <div className="p-4">
              <h2 className="mb-3 text-lg font-bold tracking-tight text-gray-800">Service Area</h2>
              <div
                className="w-full bg-center bg-no-repeat bg-cover shadow-sm aspect-video rounded-xl min-h-[200px] sm:min-h-[300px]"
                style={{
                  backgroundImage:
                    "url('https://lh3.googleusercontent.com/aida-public/AB6AXuDixHJQ2adLYmh69NASDoUymEcBJnG2M0WAFaK7nyIsJlOOtY6qlMsv4Pgv-3VBgzP-lPwp96MLe5EHncgdG-FJfehlQJpcXUEnDHlhY7Ce7rmRf_utmZZgK84ArQh3gkzZFYspbKmiPcwPDw-WBOrovIRBABe5LRbyzncnUkD2cb0iCUarogf9J4caUJs_YtvA1phh8KORyKXv6EjJ_iHVPbtXgwF6m-78O1E5DboEmYPjA8wJHDylklaBHWHGILk8SQc3Etuf_RA')",
                }}
              ></div>
            </div>
          </div>
        );

      case "users":
        return <div className="p-6 text-lg font-semibold text-center">Users Management Page</div>;
      case "providers":
        return <div className="p-6 text-lg font-semibold text-center">Providers Management Page</div>;
      case "requests":
        return <div className="p-6 text-lg font-semibold text-center">Requests Management Page</div>;
      case "more":
        return <div className="p-6 text-lg font-semibold text-center">More Options</div>;
      default:
        return null;
    }
  };

  return (
    <div className="bg-[#EBF8FF] min-h-screen flex flex-col font-['Manrope','Noto Sans',sans-serif]">
      <Header />
      <div className="flex-grow">{renderContent()}</div>
      <BottomNav />
    </div>
  );
}

